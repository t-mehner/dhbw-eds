#!/usr/bin/python

import sys

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


print("memory_initialization_radix=2;")
print("memory_initialization_vector=")

file_length = 0

with open(sys.argv[1], "r") as f:
        for i, l in enumerate(f):
            pass
        file_length = i + 1

with open(sys.argv[1], "r") as f:

	for line_number, line in enumerate(f, 1):

		stripped_line = line.strip().lower() 

		if stripped_line.startswith('nop') :
			line_result = "000000000000"
		elif stripped_line.startswith('lda') :
			substrings = stripped_line.split(" ", 2)
			argument = substrings[1]
			if argument.startswith('0b'):
				substrings = argument.split('b', 2)
				argument = substrings[1]
				argument = argument.replace(';', '')
			elif argument.startswith('0x'):
				substrings = argument.split('x', 2)
				argument = substrings[1]
				argument = argument.replace(';', '')
				argument = "{0:08b}".format(int(argument, 16))
			else:
				argument = argument.replace(';', '')
				argument = bin(int(argument, 10)&0xff).replace("0b","")
			line_result = "0001" + argument
		elif stripped_line.startswith('ldb') :
			substrings = stripped_line.split(" ", 2)
			argument = substrings[1]
			if argument.startswith('0b'):
				substrings = argument.split('b', 2)
				argument = substrings[1]
				argument = argument.replace(';', '')
			elif argument.startswith('0x'):
				substrings = argument.split('x', 2)
				argument = substrings[1]
				argument = argument.replace(';', '')
				argument = "{0:08b}".format(int(argument, 16))
			else:
				argument = argument.replace(';', '')
				argument = bin(int(argument, 10)&0xff).replace("0b","")
			line_result = "0010" + argument
		elif stripped_line.startswith('ldc'):
			substrings = stripped_line.split(" ", 2)
			argument = substrings[1]
			if argument.startswith('0b'):
				substrings = argument.split('b', 2)
				argument = substrings[1]
				argument = argument.replace(';', '')
			elif argument.startswith('0x'):
				substrings = argument.split('x', 2)
				argument = substrings[1]
				argument = argument.replace(';', '')
				argument = "{0:08b}".format(int(argument, 16))
			else:
				argument = argument.replace(';', '')
				argument = bin(int(argument, 10)&0xff).replace("0b","")
			line_result = "0011" + argument
		elif stripped_line.startswith('ldd') :
			substrings = stripped_line.split(" ", 2)
			argument = substrings[1]
			if argument.startswith('0b'):
				substrings = argument.split('b', 2)
				argument = substrings[1]
				argument = argument.replace(';', '')
			elif argument.startswith('0x'):
				substrings = argument.split('x', 2)
				argument = substrings[1]
				argument = argument.replace(';', '')
				argument = "{0:08b}".format(int(argument, 16))
			else:
				argument = argument.replace(';', '')
				argument = bin(int(argument, 10)&0xff).replace("0b","")
			line_result = "0100" + argument
		elif stripped_line.startswith('mv') :		
			substrings = stripped_line.split(" ")
			
			argument = ""
			
			for x in substrings:
				if x.startswith('mv') == 0:
					argument = argument + x
			
			argument = argument.replace(';', '')
			substrings = argument.split(",")
			
			if substrings[0].strip() == 'b' and substrings[1].strip() == 'a':
				argument = "00000000"
			elif substrings[0].strip() == 'c' and substrings[1].strip() == 'a':
				argument = "00000001"
			elif substrings[0].strip() == 'd' and substrings[1].strip() == 'a':
				argument = "00000010"
			elif substrings[0].strip() == 'a' and substrings[1].strip() == 'b':
				argument = "00000011"
			elif substrings[0].strip() == 'c' and substrings[1].strip() == 'b':
				argument = "00000100"
			elif substrings[0].strip() == 'd' and substrings[1].strip() == 'b':
				argument = "00000101"
			elif substrings[0].strip() == 'a' and substrings[1].strip() == 'c':
				argument = "00000110"
			elif substrings[0].strip() == 'b' and substrings[1].strip() == 'c':
				argument = "00000111"
			elif substrings[0].strip() == 'd' and substrings[1].strip() == 'c':
				argument = "00001000"
			elif substrings[0].strip() == 'a' and substrings[1].strip() == 'd':
				argument = "00001001"
			elif substrings[0].strip() == 'b' and substrings[1].strip() == 'd':
				argument = "00001010"
			elif substrings[0].strip() == 'c' and substrings[1].strip() == 'd':
				argument = "00001011"
			elif substrings[0].strip() == 'in' and substrings[1].strip() == 'a':
				argument = "00001100"
			elif substrings[0].strip() == 'in' and substrings[1].strip() == 'b':
				argument = "00001101"
			elif substrings[0].strip() == 'a' and substrings[1].strip() == 'out':
				argument = "00001110"
			elif substrings[0].strip() == 'b' and substrings[1].strip() == 'out':
				argument = "00001111"
			else :
				print(bcolors.FAIL + 'Error in line  {:d}: '.format(line_number) + stripped_line + bcolors.ENDC)
				break
			line_result = "0101" + argument
		elif stripped_line.startswith('add') :
			line_result = "011000000000"
		elif stripped_line.startswith('sub') :
			line_result = "011100000000"
		elif stripped_line.startswith('cp') :
			line_result = "100000000000"
		elif stripped_line.startswith('not') :
			line_result = "100100000000"
		elif stripped_line.startswith('shlc') :
			line_result = "100100000001"
		elif stripped_line.startswith('shrc') :
			line_result = "100100000010"
		elif stripped_line.startswith('rol') :
			line_result = "100100000011"
		elif stripped_line.startswith('ror') :
			line_result = "100100000100"
		elif stripped_line.startswith('and') :
			line_result = "100100000101"
		elif stripped_line.startswith('or') :
			line_result = "100100000110"
		elif stripped_line.startswith('xor') :
			line_result = "100100000111"
		elif stripped_line.startswith('tc') :
			line_result = "101000000000"
		elif stripped_line.startswith('dec') :
			line_result = "101100000000"
		elif stripped_line.startswith('jr') :
			substrings = stripped_line.split(" ", 2)
			argument = substrings[1]
			if argument.startswith('0b'):
				substrings = argument.split('b', 2)
				argument = substrings[1]
				argument = argument.replace(';', '')
			elif argument.startswith('0x'):
				substrings = argument.split('x', 2)
				argument = substrings[1]
				argument = argument.replace(';', '')
				argument = "{0:08b}".format(int(argument, 16))
			else:
				argument = argument.replace(';', '')
				argument = bin(int(argument, 10)&0xff).replace("0b","")
			line_result = "1100" + argument
		elif stripped_line.startswith('szs') :
			line_result = "110100000001"
		elif stripped_line.startswith('szc') :
			line_result = "110100000000"
		elif stripped_line.startswith('scs') :
			line_result = "000100000001"
		elif stripped_line.startswith('scc') :
			line_result = "110100000000"
		elif stripped_line.startswith('clf') :
			line_result = "111100000000"
		else :
			print(bcolors.FAIL + 'Error in line  {:d}: '.format(line_number) + stripped_line + bcolors.ENDC)
			break
		
		if line_number == file_length:
			print line_result + ";"
		else:
			print line_result + ","
